﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Auxiliar class with auxiliar methods
    /// </summary>
    class Auxiliar
    {
        private static readonly Random r = new Random();
        private static readonly object syncLock = new object();

        /// <summary>
        /// Generates a random number
        /// </summary>
        /// <param name="min">Lowest possible number</param>
        /// <param name="max">Highest possible number (+1)</param>
        /// <returns>The randomly generated number</returns>
        public int generateRandom(int min, int max)
        {
            lock (syncLock)
            {
                return r.Next(min, max);
            }
        }


        public int readInt()
        {
            Console.Write("Enter an integer ");
            int n;

            while (!int.TryParse(Console.ReadLine(), out n))
            {
                Console.Clear();
                Console.WriteLine("You entered an invalid number");
                Console.Write("Enter an integer ");
            }

            return n;
        }

        public double readReal()
        {
            Console.Write("Enter a real number ");
            double n;

            while (!double.TryParse(Console.ReadLine(), out n))
            {
                Console.Clear();
                Console.WriteLine("You entered an invalid number");
                Console.Write("Enter real numbers");
            }

            return n;
        }

    }
}
