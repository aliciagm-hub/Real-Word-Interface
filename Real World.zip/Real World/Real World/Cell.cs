﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Class cell
    /// </summary>
    class Cell
    {
        private int x;
        private int y;

        /// <summary>
        /// Generic constructor
        /// </summary>
        public Cell() { }

        /// <summary>
        /// Specific constructor
        /// </summary>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        public Cell(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        /// <summary>
        /// Row's Getter-Setter
        /// </summary>
        public int X
        {
            get
            {
                return x;
            }

            set
            {
                x = value;
            }
        }

        /// <summary>
        /// Column's Getter-Setter
        /// </summary>
        public int Y
        {
            get
            {
                return y;
            }

            set
            {
                y = value;
            }
        }

        /// <summary>
        /// Checks if two cells are the same one
        /// </summary>
        /// <param name="c">The other cell</param>
        /// <returns>True or False depending</returns>
        public bool Equals(Cell c)
        {
            return X == c.X && Y == c.Y;
        }
    }


}
