﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Neo the rebel's class
    /// </summary>
    class Neo : Personage
    {
        /// <summary>
        /// Class constructor
        /// </summary>
        public Neo() : base()
        {
            this.age = 36;
            this.name = "Neo";
        }

        /// <summary>
        /// Neo decides if he believes to be the Chosen One
        /// </summary>
        /// <returns></returns>
        public bool iBelieve()
        {
            int n = generateRandom(0, 2);
            return (n == 1);
        }


        /// <summary>
        /// Neo acts accordding to his believings
        /// </summary>
        /// <param name="t">Tabletop where he must act</param>
        public void act(Tabletop t)
        {
            int x, y;

            if (iBelieve())
            {
                Console.WriteLine("\nI Am The Chosen One");
                this.fill(t);
            }
            else
            {
                Console.WriteLine("\nI'm totally useless");
            }

            this.swap(t);

        }

        /// <summary>
        /// Checks if a cell is in the tabletopp
        /// </summary>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        /// <param name="t">Board</param>
        /// <returns></returns>
        public bool inRange(int x, int y, Tabletop t)
        {
            return ((x < t.Row && y < t.Col) && (x >= 0 && y >= 0));
        }

        /// <summary>
        /// Neo swaps his position in the map
        /// </summary>
        /// <param name="t">Tabletop where he is </param>
        public void swap(Tabletop t)
        {
            int x = this.Cell.X;
            int y = this.Cell.Y;

            while (x == this.Cell.X && y == this.Cell.Y)
            {
                x = generateRandom(0, t.Row);
                y = generateRandom(0, t.Col);
            }

            Cell aux = this.Cell;
            Personage p = null;
            Smith s = null;

            if (!t.isEmpty(x, y))
            {
                if (t.Board[x, y] is Smith)
                {
                    s = t.getSmith();
                    t.placeSmithIn(s, this.Cell.X, this.Cell.Y);
                } else
                {
                    p = t.getPersonageAt(x, y);
                    t.placePersonageIn(p, this.Cell.X, this.Cell.Y);
                }
            } else
            {
                t.Board[Cell.X, this.Cell.Y] = null;
            }

            
            t.placeNeoIn(this, x, y);
        }

        /// <summary>
        /// Fills empty spaces in the map with new generic npcs
        /// </summary>
        /// <param name="t"></param>
        public void fill(Tabletop t)
        {
            for (int x = this.Cell.X - 1; x <= this.Cell.X + 1; x++)
            {
                for (int y = this.Cell.Y - 1; y <= this.Cell.Y + 1; y++)
                {
                    if (inRange(x, y, t))
                    {
                        if (t.isEmpty(x, y))
                        {
                            if (t.Npc.Count > 0)
                            {
                                t.Board[x, y] = t.Npc.Last();
                                t.Npc.Remove(t.Npc.Last());
                            }
                        }
                    }
                }
            }
        }
    }
}
