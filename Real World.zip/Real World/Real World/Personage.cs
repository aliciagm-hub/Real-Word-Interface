﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Class for personages
    /// </summary>
    class Personage : Auxiliar
    {
        public static List<String> NAMES = new List<string> {"Michelle", "Alexander", "Claire", "James", "Coraline", "Jessica", "Erik", "Mike", "Matt", "Karen", "Wilson", "Nelson", "Peter"};
        public static List<String> CITIES = new List<string> { "New York", "Boston", "Baltimore", "Atlanta", "Detroit", "Dallas", "Denver", "Minessotta" };

        protected String name;
        protected String[] location = new string[3];
        protected String city;
        protected int age;
        protected int deathChance;
        protected Cell cell;

        /// <summary>
        /// Personage's constructor. Everything is randomize
        /// </summary>
        public Personage()
        {
            name = NAMES.ElementAt(generateRandom(0, NAMES.Count()));
            location[0] = "" + generateRandom(-90, 91);
            location[1] = "" + generateRandom(-180, 181);
            city = CITIES.ElementAt(generateRandom(0, CITIES.Count()));
            location[2] = city;
            age = generateRandom(0, 101);
            deathChance = generateRandom(0, 101);
            cell = new Cell();
        }

        /// <summary>
        /// Name's Getter-Setter
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        /// <summary>
        /// Location's Getter-Setter
        /// </summary>
        public string[] Location
        {
            get
            {
                return location;
            }

            set
            {
                location = value;
            }
        }

        /// <summary>
        /// City's Getter-Setter
        /// </summary>
        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }

        /// <summary>
        /// Age's Getter-Setter
        /// </summary>
        public int Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        /// <summary>
        /// Death Chance's Getter-Setter
        /// </summary>
        public int DeathChance
        {
            get
            {
                return deathChance;
            }

            set
            {
                deathChance = value;
            }
        }

        /// <summary>
        /// Cell's Getter-Setter
        /// </summary>
        public Cell Cell { get => cell; set => cell = value; }

        /// <summary>
        /// Increments death chance by 10
        /// </summary>
        public void incrementDeathChance()
        {
            this.deathChance += 10;
        }

        public void generate()
        {
            
        }

        /// <summary>
        /// Prints the personage's data
        /// </summary>
        public void print()
        {
            Console.WriteLine("Name: " + name + ". Age: " + age + ". Location: (" + location[0] + "º, " + location[1] + "º), " + city + ". Death Chance: " + deathChance);
        }

        public void prompt()
        {

        }
    }
}
