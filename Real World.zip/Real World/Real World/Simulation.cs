﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Main class
    /// </summary>
    class Simulation
    {
        static void Main(string[] args)
        {
            new Simulation();
        }

        public Simulation()
        {
            Tabletop t = new Tabletop();

            for (int i = 0; i < 200; i++)
            {
                t.Npc.Add(new Personage());
            }

            Neo neo = new Neo();
            Smith smith = new Smith();

            t.placeNeo(neo);
            t.placeSmith(smith);
            t.placeGeneric();

            t.print();
            Console.WriteLine("\n");

            startSimulation(t, smith, neo);
        }

        /// <summary>
        /// Simulatation constructor
        /// </summary>
        /// <param name="rows">Rows that the tabletop will have</param>
        /// <param name="columns">Columns that the tabletop will have</param>
        public Simulation(int rows, int columns)
        {
            Tabletop t = new Tabletop(rows, columns);

            for (int i = 0; i < 200; i++)
            {
                t.Npc.Add(new Personage());
            }

            Neo neo = new Neo();
            Smith smith = new Smith();

            t.placeNeo(neo);
            t.placeSmith(smith);
            t.placeGeneric();

            t.print();
            Console.WriteLine("\n");

            startSimulation(t, smith, neo);
        }

        /// <summary>
        /// Starts the Matrix Simulation
        /// </summary>
        /// <param name="t">Tabletop where the simulation will run</param>
        /// <param name="smith">Top Class machine's agent Smith</param>
        /// <param name="neo">The filthy and irresolute Neo</param>
        public void startSimulation(Tabletop t, Smith smith, Neo neo)
        {
            int maxTime = 2000;
            int currentTime = 1;

            while (currentTime <= maxTime && !bothAlone(t))
            {
                Console.WriteLine("Ronda " + currentTime + "\n");

                if (currentTime % 1 == 0)
                {
                    for (int i = 0; i < t.Row * t.Col; i++)
                    {
                        if (!t.isEmpty(i / t.Row, i % t.Col))
                        {
                            Personage p = t.Board[i / t.Row, i % t.Col];

                            if (!(p is Neo) && !(p is Smith))
                            {
                                if (p.DeathChance > 70)
                                {
                                    if (t.Npc.Count > 0)
                                    {
                                        t.Board[i / t.Row, i % t.Col] = t.Npc.Last();
                                        t.Npc.RemoveAt(t.Npc.Count() - 1);
                                    }
                                    else
                                    {
                                        t.placeNull(i / t.Row, i % t.Col);
                                    }
                                }
                                else
                                {
                                    p.incrementDeathChance();
                                }
                            }
                        }
                    }
                }

                if (currentTime % 2 == 0)
                {
                    smith.act(t);
                }

                if (currentTime % 5 == 0)
                {
                    neo.act(t);
                }

                t.print();
                
                System.Threading.Thread.Sleep(1000);
                currentTime++;
            }
        }

        /// <summary>
        /// Checks if Neo and Smith are alone
        /// </summary>
        /// <param name="t">Tabletop where the simulation is run</param>
        /// <returns></returns>
        public bool bothAlone(Tabletop t)
        {
            bool alone = true;

            for (int k = 0; (k < t.Row * t.Col) && alone; k++)
            {
                if ((t.Board[k / t.Row, k % t.Col] != null && (!(t.Board[k / t.Row, k % t.Col] is Neo) && !(t.Board[k / t.Row, k % t.Col] is Smith)))) {
                    alone = false;
                }
            }

            return alone;
        }
    }
}
