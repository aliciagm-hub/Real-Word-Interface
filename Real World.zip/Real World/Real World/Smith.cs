﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    /// <summary>
    /// Agent Smith class. Inherits from Personage
    /// </summary>
    class Smith : Personage
    {
        private static int MAX_INFECT = 10;
        private int infectCapacity;
        private List<Cell> route;

        /// <summary>
        /// Constructor for Smith
        /// </summary>
        public Smith() : base()
        {
            this.name = "Smith";
            this.age = 40;
        }

        /// <summary>
        /// Infect capcity's Getter-Setter
        /// </summary>
        public int InfectCapacity
        {
            get
            {
                return infectCapacity;
            }

            set
            {
                infectCapacity = value;
            }
        }

        /// <summary>
        /// Smith performs its complex and awesome action
        /// </summary>
        /// <param name="t">Tabletop where he will act</param>
        public void act(Tabletop t)
        {
            this.InfectCapacity = generateRandom(0, MAX_INFECT + 1);
            Console.WriteLine("Infect Capacity: " + this.InfectCapacity + "\n");
            bool[,] visited = new bool[t.Row, t.Col];

            chooseRoute(this.Cell, t.locateNeo(), t, new List<Cell>(0), new List<Cell>(0), visited);

            for (int i = 0; i < this.route.Count; i++)
            {
                Cell c = this.route.ElementAt(i);
                if (this.InfectCapacity > 0 && !(t.Board[c.X, c.Y] is Neo))
                {
                    t.Board[c.X, c.Y] = null;
                    this.InfectCapacity--;
                }
            }
        }

        /// <summary>
        /// Chooses the fastest route towards Neo and memorizes it
        /// </summary>
        /// <param name="smith">Smith's location</param>
        /// <param name="neo">Neo's location</param>
        /// <param name="t">Tabletop where everything happens</param>
        /// <param name="path">Path which is being calculated</param>
        /// <param name="pathOpt">Best path at the moment</param>
        /// <param name="visited">Matrix where checking wether a cell has being visited</param>
        public void chooseRoute(Cell smith, Cell neo, Tabletop t,  List<Cell> path, List<Cell> pathOpt, bool[,] visited)
        {
            int i, j;

            if (smith.Equals(neo))
            {
                if (isBetter(path, pathOpt))
                {
                    for (int k = 0; k < path.Count; k++)
                    {
                        pathOpt.Add(path.ElementAt(k));
                    }
                }
            }
            else
            {
                for (i = 0; i <= 1; i++)
                {
                    for (j = 0; j <= 1; j++)
                    {
                        if (Math.Abs(i) + Math.Abs(j) == 1)
                        {
                            Cell aux = new Cell(smith.X, smith.Y);
                            
                            if (smith.X < neo.X)
                            {
                                aux.X = smith.X + 1;
                            } else if (smith.X > neo.X)
                            {
                                aux.X = smith.X - 1;
                            } else if (smith.Y < neo.Y)
                            {
                                aux.Y = smith.Y + 1;
                            }
                            else if (smith.Y > neo.Y)
                            {
                                aux.Y = smith.Y - 1;
                            }

                            if (inRange(aux, t))
                            {
                                if (!isVisited(aux, visited))
                                {
                                    visited[aux.X, aux.Y] = true;
                                    path.Add(aux);
                                    chooseRoute(aux, neo, t, path, pathOpt, visited);
                                    removeVisited(smith, visited);
                                    path.RemoveAt(path.Count() - 1);
                                }
                            }
                        }
                    }
                }
            }



            this.route = new List<Cell>(pathOpt);
        }

        /// <summary>
        /// Compares two paths
        /// </summary>
        /// <param name="path">Newest path</param>
        /// <param name="pathOpt">Best path at the moment</param>
        /// <returns></returns>
        public bool isBetter(List<Cell> path, List<Cell> pathOpt)
        {
            int count = 0, countOpt = 0;

            for (int i = 0; i < path.Count; i++)
            {
                int abs = Math.Abs(path.ElementAt(i).X - path.ElementAt(i).Y);
                count += abs;
            }

            for (int i = 0; i < pathOpt.Count; i++)
            {
                int abs = Math.Abs(pathOpt.ElementAt(i).X - pathOpt.ElementAt(i).Y);
                countOpt += abs;
            }

            if (countOpt > 0)
            {

                return (count < countOpt);
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Checks if a cell is inside the board
        /// </summary>
        /// <param name="c">Cell to check</param>
        /// <param name="t">Board where it must be checked</param>
        /// <returns></returns>
        public bool inRange(Cell c, Tabletop t)
        {
            return ((c.X < t.Row && c.Y < t.Col) && (c.X >= 0 && c.Y >= 0));
        }

        /// <summary>
        /// Returns wether a cell's being visited
        /// </summary>
        /// <param name="c">Cell to check if visited</param>
        /// <param name="visited">Matrix where we mark wether cells've being visited</param>
        /// <returns></returns>
        public bool isVisited(Cell c, bool[,] visited)
        {
            return visited[c.X, c.Y];
        }

        /// <summary>
        /// Remove visited cell
        /// </summary>
        /// <param name="c">Cell to "unvist"</param>
        /// <param name="visited">Matrix where we mark wether cells've being visited</param>
        public void removeVisited(Cell c, bool[,] visited)
        {
            visited[c.X, c.Y] = false;
        }
    }
}
