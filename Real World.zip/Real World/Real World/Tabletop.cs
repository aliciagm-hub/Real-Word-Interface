﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Real_World
{
    class Tabletop : Auxiliar
    {
        public static int ROW_DEF = 5;
        public static int COL_DEF = 5;

        private int row;
        private int col;
        private Personage[,] board;
        private List<Personage> npc;

        /// <summary>
        /// Constructor with default parameters
        /// </summary>
        public Tabletop() : this(ROW_DEF, COL_DEF)
        {
        }

        /// <summary>
        /// Custom tabletop constructor
        /// </summary>
        /// <param name="row">Tabletop's rows</param>
        /// <param name="col">Tabletop's columns</param>
        public Tabletop(int row, int col)
        {
            this.row = row;
            this.col = col;
            this.board = new Personage[row, col];
            this.Npc = new List<Personage>();
        }

        /// <summary>
        /// Board's Getter-Setter
        /// </summary>
        internal Personage[,] Board
        {
            get
            {
                return board;
            }

            set
            {
                board = value;
            }
        }

        /// <summary>
        /// Rows' Getter-Setter
        /// </summary>
        public int Row
        {
            get
            {
                return row;
            }

            set
            {
                row = value;
            }
        }

        /// <summary>
        /// Columns's Getter-Setter
        /// </summary>
        public int Col
        {
            get
            {
                return col;
            }

            set
            {
                col = value;
            }
        }

        /// <summary>
        /// NPC List's Getter-Setter
        /// </summary>
        internal List<Personage> Npc { get => npc; set => npc = value; }

        /// <summary>
        /// Locates Neo in the matrix
        /// </summary>
        /// <returns>Cell where Neo is located</returns>
        public Cell locateNeo()
        {
            Cell c = new Cell(0, 0);
            bool found = false;

            for (int k = 0; k < this.row*col && !found; k++)
            {
                Personage p = this.board[k / this.row, k % this.col];
                if (p is Neo)
                {
                    c.X = k / this.row;
                    c.Y = k % this.col;
                    found = true;
                }
            }

            return c;
        }

        /// <summary>
        /// Gets Neo from the board
        /// </summary>
        /// <returns>Neo</returns>
        public Neo getNeo()
        {
            Cell c = locateNeo();

            return (Neo) this.Board[c.X, c.Y];
        }

        /// <summary>
        /// Locates Smith in the matrix
        /// </summary>
        /// <returns>Cell where Smith is located</returns>
        public Cell locateSmith()
        {
            Cell c = new Cell();
            bool found = false;

            for (int k = 0; k < this.row*col && !found; k++)
            {
                Personage p = this.board[k / this.row, k % this.col];
                if (p is Smith)
                {
                    c.X = k / this.row;
                    c.Y = k % this.col;
                    found = true;
                }
            }

            return c;
        }

        /// <summary>
        /// Gets Smith from the matrix
        /// </summary>
        /// <returns>Smith</returns>
        public Smith getSmith()
        {
            Cell c = locateSmith();

            return (this.Board[c.X, c.Y] as Smith);
        }

        /// <summary>
        /// Returns the personage located at certain cell
        /// </summary>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        /// <returns>Personage at that location</returns>
        public Personage getPersonageAt(int x, int y)
        {
            return this.Board[x, y];
        }

        /// <summary>
        /// Returns if certain cell is empty
        /// </summary>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        /// <returns>True or False depending</returns>
        public bool isEmpty(int x, int y)
        {
            return board[x, y] == null;
        }

        /// <summary>
        /// Place Neo in a random cell
        /// </summary>
        /// <param name="neo">Neo</param>
        public void placeNeo(Neo neo)
        {
            int x = generateRandom(0, row);
            int y = generateRandom(0, col);

            while (!this.isEmpty(x, y)) {
                x = generateRandom(0, row);
                y = generateRandom(0, col);
            }

            this.board[x, y] = neo;

            neo.Cell.X = x;
            neo.Cell.Y = y;
        }

        /// <summary>
        /// Place Neo in an specific location
        /// </summary>
        /// <param name="neo">Neo</param>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        public void placeNeoIn(Neo neo, int x, int y)
        {
            this.board[x, y] = neo;

            neo.Cell.X = x;
            neo.Cell.Y = y;
        }

        /// <summary>
        /// Place Smith in a random empty cell
        /// </summary>
        /// <param name="smith"></param>
        public void placeSmith(Smith smith)
        {
            int x = generateRandom(0, row);
            int y = generateRandom(0, col);

            while (!this.isEmpty(x, y))
            {
                x = generateRandom(0, 4 + 1);
                y = generateRandom(0, 4 + 1);
            }

            this.board[x, y] = smith;

            smith.Cell.X = x;
            smith.Cell.Y = y;
        }

        /// <summary>
        /// Place Smith in an specific location
        /// </summary>
        /// <param name="smith">Smith</param>
        /// <param name="x">row</param>
        /// <param name="y">column</param>
        public void placeSmithIn(Smith smith, int x, int y)
        {
            this.board[x, y] = smith;

            smith.Cell.X = x;
            smith.Cell.Y = y;
        }

        /// <summary>
        /// Fills the empty spaces with generic NPC characters
        /// </summary>
        public void placeGeneric()
        {
            for (int i = 0; i < this.row*col - 2; i++)
            {
                int x = generateRandom(0, 5);
                int y = generateRandom(0, 5);

                while (!this.isEmpty(x, y))
                {
                    x = generateRandom(0, 5);
                    y = generateRandom(0, 5);
                }

                this.board[x, y] = this.Npc.Last();
                this.Npc.RemoveAt(this.Npc.Count - 1);
            }
        }

        /// <summary>
        /// Place a specific personage in a specific cell
        /// </summary>
        /// <param name="p">Personage to place</param>
        /// <param name="x">Row</param>
        /// <param name="y">Column</param>
        public void placePersonageIn(Personage p, int x, int y)
        {
            this.board[x, y] = p;

            p.Cell.X = x;
            p.Cell.Y = y;
        }

        /// <summary>
        /// Clears a certain cell
        /// </summary>
        /// <param name="x">Row</param>
        /// <param name="y">Column</param>
        public void placeNull(int x, int y)
        {
            this.board[x, y] = null;
        }

        /// <summary>
        /// Prints the board
        /// </summary>
        public void print()
        {
            int row = 0;
            int col = 0;

            Console.WriteLine("\n");

            for (int i = 0; i < this.row * this.col; i++)
            {
                if (col == 5)
                {
                    col = 0;
                    row++;
                    Console.WriteLine();
                }

                if (this.board[row, col] is Neo)
                {
                    Console.Write("N ");
                }
                else if (this.board[row, col] is Smith)
                {
                    Console.Write("S ");
                }
                else if (this.board[row, col] is Personage)
                {
                    Console.Write("P ");
                }
                else
                {
                    Console.Write("  ");
                }

                col++;
            }

            Console.WriteLine("\n");
        }
    }
}
